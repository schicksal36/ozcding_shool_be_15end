document.addEventListener("DOMContentLoaded", () => {
  const product_data = [
    { category: "상의", brand: "Supreme", product: "슈프림 박스로고 후드티", price: "390,000" },
    { category: "하의", brand: "DIESEL", product: "디젤 트랙 팬츠", price: "188,000" },
    { category: "신발", brand: "Nike", product: "에어포스 1", price: "137,000" },
    { category: "패션잡화", brand: "Music&Goods", product: "빵빵이 키링", price: "29,000" },
  ];

  const searchBtn = document.getElementById("searchBtn");
  const searchInput = document.getElementById("searchInput");
  const categorySelect = document.getElementById("inlineFormSelectPref");
  const darkToggle = document.getElementById("darkToggle");
  const signupBtn = document.getElementById("signupBtn");
  const signupCard = document.getElementById("signupCard");

  let table = $("#product_data_Table").DataTable({
    data: product_data,
    columns: [
      { data: "category", title: "카테고리" },
      { data: "brand", title: "브랜드" },
      { data: "product", title: "상품명" },
      { data: "price", title: "가격" },
    ],
    pageLength: 5,
    ordering: true,
    searching: true,
    lengthChange: false,
    language: {
      search: "검색:",
      paginate: { previous: "이전", next: "다음" },
      info: "_TOTAL_개 중 _START_–_END_ 표시",
      infoEmpty: "표시할 데이터 없음",
      zeroRecords: "검색 결과가 없습니다.",
    },
    columnDefs: [{ className: "text-center", targets: "_all" }]
  });

  searchBtn.addEventListener("click", () => {
    const keyword = searchInput.value.trim();
    const category = categorySelect.value;
    const filtered = product_data.filter((item) => {
      const matchCategory = category === "카테고리 선택..." || item.category === category;
      const matchKeyword = keyword === "" || item.product.includes(keyword);
      return matchCategory && matchKeyword;
    });
    table.clear().rows.add(filtered).draw();
  });

  function updateDarkLabel() {
    darkToggle.textContent = document.body.classList.contains("dark-mode")
      ? "☀ 라이트모드"
      : "🌙 다크모드";
  }
  updateDarkLabel();
  darkToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    updateDarkLabel();
  });

  const clockDiv = document.getElementById("clock");
// ✅ 시계 업데이트 함수 (한국식 날짜 + 요일)
function updateClock() {
  const n = new Date();
  const days = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];

  const year = n.getFullYear();
  const month = String(n.getMonth() + 1).padStart(2, "0");
  const day = String(n.getDate()).padStart(2, "0");
  const hours = String(n.getHours()).padStart(2, "0");
  const minutes = String(n.getMinutes()).padStart(2, "0");
  const seconds = String(n.getSeconds()).padStart(2, "0");
  const weekday = days[n.getDay()];

  const formatted = `${year}년 ${month}월 ${day}일 ${hours}시${minutes}분 ${seconds}초 (${weekday})`;
  document.getElementById("clock").textContent = "🕒 " + formatted;
}

setInterval(updateClock, 1000);
updateClock();


  signupBtn.addEventListener("click", () => {
    signupCard.style.display = signupCard.style.display === "none" ? "block" : "none";
  });

  document.getElementById("submitSignup").addEventListener("click", () => {
    const id = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const pw = document.getElementById("password").value.trim();

    if (!id || !email || !pw) return alert("⚠️ 모든 항목을 입력해주세요!");
    if (!email.includes("@") || !email.includes(".")) return alert("⚠️ 이메일 형식이 올바르지 않습니다!");
    if (pw.length < 6) return alert("⚠️ 비밀번호는 6자 이상이어야 합니다!");

    alert(`✅ 회원가입 완료!\nID: ${id}\nEmail: ${email}`);
  });
});
